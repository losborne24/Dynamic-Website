module.exports = {
  mongoURI: 'mongodb://localhost/loginapp'
};
